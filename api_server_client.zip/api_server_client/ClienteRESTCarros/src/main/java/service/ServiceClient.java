package service;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
 
import entity.Carro;
import entity.Carros;
 
 
 
public class ServiceClient {
 
	/**GERENCIA A INFRAESTRUTURA DE COMUNIÇÃO DO LADO 
	 * CLIENTE PARA EXECUTAR AS SOLICITAÇÕES REALIZADAS*/
	private Client client;
 
	/**ACESSA UM RECURSO IDENTIFICADO PELO URI(Uniform Resource Identifier/Identificador Uniforme de Recursos)*/
	private WebTarget webTarget;
 
	/**URL DO SERVIÇO REST */
	private final String URL_SERVICE = "http://localhost:3000/carros";
 
	/**CONSTRUTOR DA NOSSA CLASSE*/
	public ServiceClient(){
 
		this.client = ClientBuilder.newClient();  
	}
 
	/**CADASTRA UMA NOVA CARRO ATRAVÉS DA OPERAÇÃO cadastrar(MÉTODO HTTP: POST) */
	public String CadastrarCarro(Carro carro){
 
		this.webTarget = this.client.target(URL_SERVICE);
 
		Invocation.Builder invocationBuilder =  this.webTarget.request("application/json;charset=UTF-8");
 
		Response response = invocationBuilder.post(Entity.entity(carro, "application/json;charset=UTF-8"));
 
		return response.readEntity(String.class);
 
	}
 
	/**ALTERA UM REGISTRO JÁ CADASTRADO ATRAVÉS DA OPERAÇÃO alterar(MÉTODO HTTP:PUT)*/
	public String AlterarCarro(Carro carro){
 
		this.webTarget = this.client.target(URL_SERVICE).path(String.valueOf(carro.getId()));
 
		Invocation.Builder invocationBuilder =  this.webTarget.request("application/json;charset=UTF-8");
 
		Response response = invocationBuilder.put(Entity.entity(carro, "application/json;charset=UTF-8"));
 
		return response.readEntity(String.class);
 
	}
 
	/**CONSULTA TODOS OS CARROS CADASTRADAS NO SERVIÇO (MÉTODO HTTP:GET)*/
	public Carros ConsultarTodosCarros(){
 
		this.webTarget = this.client.target(URL_SERVICE);
 
		Invocation.Builder invocationBuilder =  this.webTarget.request("application/json;charset=UTF-8");
 
		Response response = invocationBuilder.get();
 
		return response.readEntity(Carros.class);
 
	}
 
	/**CONSULTA UM CARRO PELO CÓDIGO (MÉTODO HTTP: GET)*/
	public Carro ConsultarCarroPorId(int id){
 
		this.webTarget = this.client.target(URL_SERVICE).path(String.valueOf(id));
 
		Invocation.Builder invocationBuilder = this.webTarget.request("application/json;charset=UTF-8");
 
		Response response = invocationBuilder.get();
 
		return response.readEntity(Carro.class);
 
	}
 
 
	/**EXCLUI UM REGISTRO CADASTRADO PELO CÓDIGO(MÉTODO HTTP:delete)*/
	public String ExcluirCarro(int id){
 
		this.webTarget = this.client.target(URL_SERVICE).path(String.valueOf(id));
 
		Invocation.Builder invocationBuilder = this.webTarget.request("application/json;charset=UTF-8");
 
		Response response = invocationBuilder.delete();
 
		return response.readEntity(String.class);
 
	}
 
}
