package entity;

import java.util.ArrayList;

public class Carros extends ArrayList<Carro>{
    
    private static final long serialVersionUID = 1L;
    
}
