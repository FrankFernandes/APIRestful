import javax.swing.JOptionPane;
 
import entity.Carro;
import entity.Carros;
import service.ServiceClient;
 
public class App {
 
	public static void main(String[] args) {
 
		String opcao = JOptionPane.showInputDialog(null,
				"Escolha uma opção: \n" + " 1-CADASTRAR | 2-CONSULTAR | 3-EXCLUIR | 4-ALTERAR | 5-LISTAR TODOS",
				"OPÇÕES", JOptionPane.PLAIN_MESSAGE);
 
		// SAI DO PROGRAMA SE NÃO INFORMAR NENHUMA OPÇÃO
		if (opcao == null)
			System.exit(0);
 
		switch (Integer.parseInt(opcao)) {
		case 1:
			Cadastrar();
			break;
		case 2:
			Consultar();
			break;
		case 3:
			Excluir();
			break;
		case 4:
			Alterar();
			break;
		case 5:
			ListarTodos();
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!");
			main(null);
			break;
		}
 
	}
 
	public static void Cadastrar() {
 
		// DECLARANDO O OBJETO DA NOSSA CLASSE QUE ACESSA O SERVIÇO REST
		ServiceClient client = new ServiceClient();
 
		// CAPTURA AS INFORMAÇÕES PARA CADASTRO
		String modelo = JOptionPane.showInputDialog(null, "Modelo:", "Novo Cadastro", JOptionPane.PLAIN_MESSAGE);
		int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Ano:", "Novo Cadastro", JOptionPane.PLAIN_MESSAGE));
                String cor = JOptionPane.showInputDialog(null, "Cor:", "Novo Cadastro", JOptionPane.PLAIN_MESSAGE);
 
		// SETA OS VALORES NO NOSSO JAVABEANS
		Carro carro = new Carro();
		carro.setModelo(modelo);
		carro.setAno(ano);
                carro.setCor(cor);
 
		// EFETUA O CADASTRO DE UM NOVO CARRO
		String resultado = client.CadastrarCarro(carro);
 
		// MENSAGEM COM O RESULTADO
		JOptionPane.showMessageDialog(null, resultado);
 
		// CHAMANDO O MÉTODO PRINCIPAL PARA COMEÇAR A EXECUTAR AS OPÇÕES
		// NOVAMENTE
		main(null);
 
	}
 
	public static void Consultar() {
 
		// DECLARANDO O OBJETO DA NOSSA CLASSE QUE ACESSA O SERVIÇO REST
		ServiceClient client = new ServiceClient();
 
		// CAPTURA O CÓDIGO A SER CONSULTADO
		String id = JOptionPane.showInputDialog(null, "Informe o ID  para consulta:", "Consultar",
				JOptionPane.PLAIN_MESSAGE);
 
		// CONSULTA UM CARRO PELO CÓDIGO
		Carro carro = client.ConsultarCarroPorId(Integer.parseInt(id));
 
		if (carro == null) {
 
			JOptionPane.showMessageDialog(null, "Carro não encontrado!");
 
			// CHAMANDO A FUNÇÃO PRINCIPAL DO NOSSO SISTEMA
			main(null);
		} else {
 
			String resultado = null;
 
			// MONTA O RESULTADO PARA MOSTRARMOS NA MENSAGEM DE SAIDA
			resultado = "ID: " + String.valueOf(carro.getId()) + "\n";
			resultado += "Modelo:   " + carro.getModelo() + "\n";
			resultado += "Ano:   " + carro.getAno() + "\n";
                        resultado += "Cor:   " + carro.getCor();
 
			// MENSAGEM COM O RESULTADO
			JOptionPane.showMessageDialog(null, resultado);
 
			// CHAMANDO A FUNÇÃO PRINCIPAL DO NOSSO SISTEMA
			main(null);
		}
 
	}
 
	public static void Excluir() {
 
		// DECLARANDO O OBJETO DA NOSSA CLASSE QUE ACESSA O SERVIÇO REST
		ServiceClient client = new ServiceClient();
 
		// CAPTURA O CÓDIGO A SER EXCLUIDO
		String id = JOptionPane.showInputDialog(null, "Informe o ID para excluir:", "Excluir",
				JOptionPane.PLAIN_MESSAGE);
 
		// EXCLUI UM REGISTRO PELO CÓDIGO
		String resultado = client.ExcluirCarro(Integer.parseInt(id));
 
		// MENSAGEM COM O RESULTADO
		JOptionPane.showMessageDialog(null, resultado);
 
		// CHAMANDO O MÉTODO PRINCIPAL PARA COMEÇAR A EXECUTAR AS OPÇÕES
		// NOVAMENTE
		main(null);
 
	}
 
	public static void Alterar() {
 
		// DECLARANDO O OBJETO DA NOSSA CLASSE QUE ACESSA O SERVIÇO REST
		ServiceClient client = new ServiceClient();
 
		// CAPTURA O CÓDIGO A SER CONSULTADO
		String id = (String) JOptionPane.showInputDialog(null, "Informe o ID para alteração:", "Alterar",
				JOptionPane.PLAIN_MESSAGE);
 
		// CONSULTA UM CARRO PELO CÓDIGO
		Carro carro = client.ConsultarCarroPorId(Integer.parseInt(id));
 
		if (carro == null) {
 
			JOptionPane.showMessageDialog(null, "Carro não encontrado!");
 
			// CHAMANDO A FUNÇÃO PRINCIPAL DO NOSSO SISTEMA
			main(null);
		} else {
 
			// PEGA O NOME INFORMADO PARA ALTERAÇÃO
			String modelo = (String) JOptionPane.showInputDialog(null, "Modelo:",
					"Alterar registro - ID:" + carro.getId(), JOptionPane.PLAIN_MESSAGE, null, null,
					carro.getModelo());
 
			// PEGA O SEXO INFORMADO PARA ALTERAÇÃO
			String ano = (String) JOptionPane.showInputDialog(null, "Ano:",
					"Alterar registro - ID:" + carro.getId(), JOptionPane.PLAIN_MESSAGE, null, null,
					carro.getAno());
                        
                        String cor = (String) JOptionPane.showInputDialog(null, "Cor:",
					"Alterar registro - ID:" + carro.getId(), JOptionPane.PLAIN_MESSAGE, null, null,
					carro.getCor());
 
			// ATUALIZANDO OS DADOS DO CARRO QUE CONSULTAMOS
			carro.setModelo(modelo);
			carro.setAno(Integer.parseInt(ano));
                        carro.setCor(cor);
			String resultado = client.AlterarCarro(carro);
 
			// MENSAGEM COM O RESULTADO
			JOptionPane.showMessageDialog(null, resultado);
 
			// CHAMANDO O MÉTODO PRINCIPAL PARA COMEÇAR A EXECUTAR AS OPÇÕES
			// NOVAMENTE
			main(null);
		}
 
	}
 
	public static void ListarTodos() {
 
		// DECLARANDO O OBJETO DA NOSSA CLASSE QUE ACESSA O SERVIÇO REST
		ServiceClient client = new ServiceClient();
 
		// CONSULTA TODOS OS CARROS CADASTRADAS
		Carros carros = client.ConsultarTodosCarros();
 
		StringBuilder stringBuiderDetalhesCarro = new StringBuilder();
 
		// MONTANDO A LSITA DE CARROS
		for (Carro carro : carros) {
 
			stringBuiderDetalhesCarro.append("ID: ");
			stringBuiderDetalhesCarro.append(carro.getId());
			stringBuiderDetalhesCarro.append(" Modelo: ");
			stringBuiderDetalhesCarro.append(carro.getModelo());
			stringBuiderDetalhesCarro.append(" Ano: ");
			stringBuiderDetalhesCarro.append(carro.getAno());
                        stringBuiderDetalhesCarro.append(" Cor: ");
			stringBuiderDetalhesCarro.append(carro.getCor());
			stringBuiderDetalhesCarro.append("\n\n");
 
		}
 
		// MOSTRA A LISTA DE CARROS ENCONTRADOS NA BASE
		JOptionPane.showMessageDialog(null, stringBuiderDetalhesCarro.toString());
 
		// CHAMANDO O MÉTODO PRINCIPAL PARA COMEÇAR A EXECUTAR AS OPÇÕES
		// NOVAMENTE
		main(null);
	}
}